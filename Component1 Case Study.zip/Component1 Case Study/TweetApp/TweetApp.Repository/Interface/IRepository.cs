﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using TweetApp.Domain;

namespace TweetApp.Repository.Interface
{
    public interface IRepository<T>
    {
        IQueryable<T> GetAll();
        IQueryable<T> GetbyID(Expression<Func<T, bool>> expression);
        bool Createdata(T entity);
        void Updatedata(T entity);
        void Deletedata(T entity);        
    }
}
