﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using TweetApp.Repository.Interface;

namespace TweetApp.Repository
{
    public class Repository<T>  : IRepository<T> where T : class
    {
        protected ApplicationContext ApplicationContext { get; set; }

        public Repository(ApplicationContext applicationContext)
        {
            this.ApplicationContext = applicationContext;
        }

        // Get All
        public IQueryable<T> GetAll()
        {
            return this.ApplicationContext.Set<T>().AsNoTracking();
        }

        // Get By Condition
        public IQueryable<T> GetbyID(Expression<Func<T, bool>> expression)
        {
            return this.ApplicationContext.Set<T>().Where(expression).AsNoTracking();
        }

        // Save Changes
        public void Save()
        {
            this.ApplicationContext.SaveChanges();
        }

        // Create
        public bool Createdata(T entity)
        {
            try
            {
                this.ApplicationContext.Set<T>().Add(entity);
                Save();
                return true;
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return false;
            }
        }

        // Update
        public void Updatedata(T entity)
        {
            this.ApplicationContext.Set<T>().Update(entity);
            Save();
        }

        // Delete
        public void Deletedata(T entity)
        {
            this.ApplicationContext.Set<T>().Remove(entity);
        }
    }
}
