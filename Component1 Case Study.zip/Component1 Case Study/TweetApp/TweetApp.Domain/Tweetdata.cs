﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TweetApp.Domain
{
    [Table("TA_Tweet")]
    public class Tweetdata
    {
        [Key]
        public int tweetId { get; set; }

        [ForeignKey("Userdetails")]
        public int userId { get; set; }
        public string tweetDesc { get; set; }
        public DateTime createdAt { get; set; }

    }
}
