﻿using System;
using System.Collections.Generic;
using System.Linq;
using TweetApp.Domain;
using TweetApp.Repository.Interface;
using TweetApp.Service.Interface;

namespace TweetApp.Service
{
    public class TweetService : ITweetservice
    {
        private readonly IRepository<Tweetdata> TweetRepository;

        public TweetService(IRepository<Tweetdata> repository)
        {
            this.TweetRepository = repository;
        }
       

        // Get User's Tweets By tweet Id
        public Tweetdata GetTweetById(int Id)
        {
            Tweetdata tweetById = new Tweetdata();
            try
            {
                tweetById = TweetRepository.GetbyID(x => x.tweetId.Equals(Id)).FirstOrDefault();   
                
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return tweetById;
        }

        // Get User's Tweets By User Id
        public List<Tweetdata> GetTweetsByUserId(int id)
        {
            List<Tweetdata> tweetsByUserId = new List<Tweetdata>();
            try
            {
                tweetsByUserId = TweetRepository.GetbyID(x => x.userId.Equals(id)).ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return tweetsByUserId;
        }

        //Get All tweets
        public List<Tweetdata> GetAllTweetsdesc()
        {
            List<Tweetdata> allTweets = new List<Tweetdata>();
            try
            {
                allTweets = TweetRepository.GetAll().ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }            
            return allTweets;
        }

        //Create Tweet
        public string CreateTweet(Tweetdata tweetdata)
        {
            try
            {
                if (tweetdata.userId != 0 && !string.IsNullOrEmpty(tweetdata.tweetDesc))
                {
                    tweetdata.createdAt = DateTime.Now;
                    if (TweetRepository.Createdata(tweetdata))
                        return "Tweet was created sucessfully";
                    else
                        return "Tweet was not created sucessfully";
                }
                else
                    return "Input is not valid please check the input";
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return "Exception is caught in CreateTweet "+ex;
            }
        }
    }
}
