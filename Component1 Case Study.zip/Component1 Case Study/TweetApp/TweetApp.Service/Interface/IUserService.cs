﻿using System;
using System.Collections.Generic;
using System.Text;
using TweetApp.Domain;

namespace TweetApp.Service.Interface
{
    public interface IUserService
    {
        string RegisterUser(Userdetails User);
        Userdetails LoginUser(Userdetails User);
        bool ChangePassword(int id, ChangePassword changePassword);
        bool ResetPassword(ChangePassword user);
        Userdetails GetUserById(int id);
        List<Userdetails> GetAllUsersdetails();
    }
}
