﻿using System;
using System.Collections.Generic;
using System.Text;
using TweetApp.Domain;

namespace TweetApp.Service.Interface
{
    public interface ITweetservice
    {
        Tweetdata GetTweetById(int id);

        List<Tweetdata> GetTweetsByUserId(int id);

        List<Tweetdata> GetAllTweetsdesc();

        string CreateTweet(Tweetdata tweetdesc);
    }
}
