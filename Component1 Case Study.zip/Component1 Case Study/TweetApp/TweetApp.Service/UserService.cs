﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TweetApp.Domain;
using TweetApp.Repository.Interface;
using TweetApp.Service.Interface;

namespace TweetApp.Service
{
    public class UserService : IUserService
    {
        private readonly IRepository<Userdetails> repository;
        public UserService(IRepository<Userdetails> repository)
        {
            this.repository = repository;
        }

        // User Registeration
        public string RegisterUser(Userdetails userdetails)
        {
            bool creationStatus = false;
            try
            {
                if (!string.IsNullOrEmpty(userdetails.first_name) && !string.IsNullOrEmpty(userdetails.gender) && !string.IsNullOrEmpty(userdetails.email) && !string.IsNullOrEmpty(userdetails.password))
                {
                    var userExists = repository.GetbyID(x => x.email.Equals(userdetails.email)).FirstOrDefault();
                    if (userExists == null)
                    {
                        userdetails.createdAt = DateTime.Now;
                        creationStatus = repository.Createdata(userdetails);
                        return "User was successfully created";
                    }
                    else
                        return "User Exists please give a new Email Id";

                }
                else
                    return "User not Created please provide correct input";
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return msg;
            }
        }

        // User Login
        public Userdetails LoginUser(Userdetails userdetails)
        {
            Userdetails user = new Userdetails();
            try
            {
                user = repository.GetbyID(x => x.email.Equals(userdetails.email)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return user;
        }

        // Change Password
        public bool ChangePassword(int id, ChangePassword changePassword)
        {
            Userdetails updateUser = new Userdetails();
            try
            {
                if (string.IsNullOrEmpty(changePassword.oldpassword) && string.IsNullOrEmpty(changePassword.oldpassword))
                {
                    updateUser = repository.GetbyID(x => x.userId.Equals(id) && x.password.Equals(changePassword.oldpassword)).FirstOrDefault();

                    if (updateUser != null)
                    {
                        updateUser.password = changePassword.newPassword;
                        repository.Updatedata(updateUser);
                        return true;
                    }
                    
                }

            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return false;
        }

        // Reset Password
        public bool ResetPassword(ChangePassword userdetails)
        {
            Userdetails user = new Userdetails();
            try
            {
                if (!string.IsNullOrEmpty(userdetails.email) && !string.IsNullOrEmpty(userdetails.oldpassword) && !string.IsNullOrEmpty(userdetails.newPassword))
                {
                    user = repository.GetbyID(x => x.email.Equals(userdetails.email) && x.password.Equals(userdetails.oldpassword)).FirstOrDefault();
                    if (user != null)
                    {
                            user.password = userdetails.newPassword;
                            repository.Updatedata(user);
                            return true;
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return false;
            }
            return false;
        }

        // Get User By User Id
        public Userdetails GetUserById(int id)
        {
            Userdetails userById = new Userdetails();
            try
            {
                userById = repository.GetbyID(x => x.userId.Equals(id)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return userById;
        }

        // Get All Users 
        public List<Userdetails> GetAllUsersdetails()
        {
            List<Userdetails> allUsers = new List<Userdetails>();
            try
            {
                allUsers = repository.GetAll().ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return allUsers;
        }
    }
}
