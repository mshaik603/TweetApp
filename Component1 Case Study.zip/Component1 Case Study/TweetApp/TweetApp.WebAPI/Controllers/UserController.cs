﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Domain;
using TweetApp.Service.Interface;

namespace TweetApp.WebAPI.Controllers
{
    public class UserController : Controller
    {
        private IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }

        

        // User Login
        [HttpPost]
        [Route("api/UserLogin")]
        public IActionResult Login([FromBody] Userdetails user)
        {
            try
            {
                var userExist = userService.LoginUser(user);
                if (userExist == null)
                {
                    return NotFound("User not found");
                }
                else if (userExist != null && (userExist.password == user.password))
                {
                    return Ok("User Logged in successfully");
                }
                else
                {
                    return NotFound("Username or Password is incorrect");
                }
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at Login " + ex);
            }
        }

        // Change Password
        [HttpPut]
        [Route("api/ChangePassword/{id}")]
        public IActionResult ChangePassword(int id, [FromBody] ChangePassword changePassword)
        {
            try
            {
                bool valid = userService.ChangePassword(id, changePassword);
                if (valid)
                {
                    return Ok("Password changed successfully");
                }
                return NotFound("Old password is incorrect");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at ChangePassword " + ex);
            }
        }

        // Reset Password
        [HttpPut]
        [Route("api/ResetPassword")]
        public IActionResult ResetPassword([FromBody] ChangePassword user)
        {
            try
            {
                bool valid = userService.ResetPassword(user);
                if (valid)
                {
                    return Ok("Password changed successfully");
                }
                return NotFound("Email id or DOB or password is incorrect");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at Reset Password "+ex);
            }
           
        }

        // Get User By User Id
        [HttpGet]
        [Route("api/GetUserDetailsById/{id}")]
        public IActionResult GetUserById(int id)
        {
            Userdetails userById = new Userdetails();
            try
            {
                userById = userService.GetUserById(id);
                if (userById != null)
                {
                    return Ok(userById);
                }
                return NotFound("User not found");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at GetUserDetailsById "+ex);
            }
            
        }

        // Get All Users 
        [HttpGet]
        [Route("api/GetAllUsersdeatils")]
        public IActionResult GetAllUsers()
        {
            List<Userdetails> allUsers = new List<Userdetails>();
            try
            {
                allUsers = userService.GetAllUsersdetails().ToList();
                if (allUsers != null)
                {
                    return Ok(allUsers);
                }
                return NotFound("Users not found");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at GetAllUsersdeatils " + ex);
            }
        }

        //Register new User
        [HttpPost]
        [Route("api/RegisterUser")]

        public IActionResult Register([FromBody] Userdetails userdetails)
        {
            try
            {
                var response = userService.RegisterUser(userdetails);

                return Ok(response);
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
                return BadRequest("Exception caught at RegisterUser " + ex);
            }
        }

    }
}
