1. Import the PostMan collections
2. Visualu Studio 2019 and Microsoft sql Server 2012+ required 