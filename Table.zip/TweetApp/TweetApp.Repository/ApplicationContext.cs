﻿using Microsoft.EntityFrameworkCore;
using System;
using TweetApp.Domain;

namespace TweetApp.Repository
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        { }

        public DbSet<Tweetdata> tweetdata { get; set; }
        public DbSet<Userdetails> userdetails { get; set; }
    }
}
