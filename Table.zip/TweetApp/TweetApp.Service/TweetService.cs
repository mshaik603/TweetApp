﻿using System;
using System.Collections.Generic;
using System.Linq;
using TweetApp.Domain;
using TweetApp.Repository.Interface;
using TweetApp.Service.Interface;

namespace TweetApp.Service
{
    public class TweetService : ITweetservice
    {
        private readonly IRepository<Tweetdata> repository;

        public TweetService(IRepository<Tweetdata> repository)
        {
            this.repository = repository;
        }

        // Get User's Tweets By tweet Id
        public Tweetdata GetTweetById(int Id)
        {
            Tweetdata tweetById = new Tweetdata();
            try
            {
                tweetById = repository.GetbyID(x => x.tweetId.Equals(Id)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return tweetById;
        }

        // Get User's Tweets By User Id
        public List<Tweetdata> GetTweetsByUserId(int id)
        {
            List<Tweetdata> tweetsByUserId = new List<Tweetdata>();
            try
            {
                tweetsByUserId = repository.GetbyID(x => x.userId.Equals(id)).ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return tweetsByUserId;
        }

        //Get All tweets
        public List<Tweetdata> GetAllTweetsdesc()
        {
            List<Tweetdata> allTweets = new List<Tweetdata>();
            try
            {
                allTweets = repository.GetAll().ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return allTweets;
        }

        //Create Tweet
        public bool CreateTweet(Tweetdata tweetdata)
        {
            bool creationStatus = false;
            try
            {
                tweetdata.createdAt = DateTime.Now;
                creationStatus = repository.Createdata(tweetdata);
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return false;
            }
            return creationStatus;
        }
    }
}
