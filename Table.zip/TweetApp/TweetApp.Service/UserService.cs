﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TweetApp.Domain;
using TweetApp.Repository.Interface;
using TweetApp.Service.Interface;

namespace TweetApp.Service
{
    public class UserService : IUserService
    {
        private readonly IRepository<Userdetails> repository;
        public UserService(IRepository<Userdetails> repository)
        {
            this.repository = repository;
        }

        // User Registeration
        public bool RegisterUser(Userdetails userdetails)
        {
            bool creationStatus = false;
            try
            {
                userdetails.createdAt = DateTime.Now;
                creationStatus = repository.Createdata(userdetails);
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return false;
            }
            return creationStatus;
        }

        // User Login
        public Userdetails LoginUser(Userdetails userdetails)
        {
            Userdetails user = new Userdetails();
            try
            {
                user = repository.GetbyID(x => x.email.Equals(userdetails.email)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return user;
        }

        // Change Password
        public bool ChangePassword(int id, ChangePassword changePassword)
        {
            Userdetails updateUser = new Userdetails();
            try
            {
                updateUser = repository.GetbyID(x => x.userId.Equals(id) && x.password.Equals(changePassword.oldpassword)).FirstOrDefault();

                if (updateUser != null)
                {
                    updateUser.password = changePassword.newPassword;
                    repository.Updatedata(updateUser);
                    return true;
                }

            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                throw;
            }
            return false;
        }

        // Reset Password
        public bool ResetPassword(Userdetails userdetails)
        {
            Userdetails user = new Userdetails();
            try
            {
                user = repository.GetbyID(x => x.email.Equals(userdetails.email)).FirstOrDefault();
                if (user != null)
                {
                    if (userdetails.dob.ToString("dd/MM/yyyy") == user.dob.ToString("dd/MM/yyyy"))
                    {
                        user.password = userdetails.password;
                        repository.Updatedata(user);
                        return true;
                    }
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return false;
        }

        // Get User By User Id
        public Userdetails GetUserById(int id)
        {
            Userdetails userById = new Userdetails();
            try
            {
                userById = repository.GetbyID(x => x.userId.Equals(id)).FirstOrDefault();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return userById;
        }

        // Get All Users 
        public List<Userdetails> GetAllUsersdetails()
        {
            List<Userdetails> allUsers = new List<Userdetails>();
            try
            {
                allUsers = repository.GetAll().ToList();
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
            return allUsers;
        }
    }
}
