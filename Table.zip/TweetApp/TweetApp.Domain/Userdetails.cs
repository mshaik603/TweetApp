﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace TweetApp.Domain
{
    [Table("TA_User")]
    public class Userdetails
    {
        [Key]
        public int userId { get; set; }
        [Required]
        public string first_name { get; set; }
        public string last_name { get; set; }
        [Required]
        public string gender { get; set; }
        //[DataType(DataType.Date)]
        //[DisplayFormat(DataFormatString = "{dd-MM-yyyy}",ApplyFormatInEditMode = true)]
        public DateTime dob { get; set; }

        [Required]
        [EmailAddress]
        public string email { get; set; }

        [Required]
        public string password { get; set; }
        public DateTime createdAt { get; set; }
    }
}
