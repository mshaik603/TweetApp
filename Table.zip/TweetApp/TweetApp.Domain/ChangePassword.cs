﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TweetApp.Domain
{
    public class ChangePassword
    {
        public string oldpassword { get; set; }
        public string newPassword { get; set; }
    }
}
