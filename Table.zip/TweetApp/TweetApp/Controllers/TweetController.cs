﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TweetApp.Domain;
using TweetApp.Repository;
using TweetApp.Repository.Interface;
using TweetApp.Service;
using TweetApp.Service.Interface;


namespace TweetApp.WebAPI.Controllers
{
    public class TweetController : Controller
    {
        private ITweetservice tweetService;

        public TweetController(ITweetservice tweetService)
        {
            this.tweetService = tweetService;
        }

        // Get Tweet By Tweet Id
        [HttpGet]
        [Route("api/GetTweetdescById/{id}")]
        public IActionResult GetTweetById(int id)
        {
            Tweetdata tweet = new Tweetdata();
            try
            {
                tweet = tweetService.GetTweetById(id);
                if (tweet != null)
                {
                    return Ok(tweet);
                }
                return NotFound("Tweet not found");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return BadRequest("Error");
        }

        // Get User's Tweets By User Id
        [HttpGet]
        [Route("api/GetTweetsdescByUserId/{id}")]
        public IActionResult GetTweetsByUserId(int id)
        {
            List<Tweetdata> tweets = new List<Tweetdata>();
            try
            {
                tweets = tweetService.GetTweetsByUserId(id);
                if (tweets != null)
                {
                    return Ok(tweets);
                }
                return NotFound("Tweet not found");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return BadRequest("Error");
        }

        // Getting All Tweets
        [Route("api/GetAllTweetsdesc")]
        public IActionResult GetAllTweets()
        {
            List<Tweetdata> allTweets = new List<Tweetdata>();
            try
            {
                allTweets = tweetService.GetAllTweetsdesc();
                if (allTweets != null)
                {
                    return Ok(allTweets);
                }
                return NotFound("Tweets not found");
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return BadRequest("Error");
        }

        // Create a Tweet
        [Route("api/CreateTweet")]
        [HttpPost]
        public IActionResult CreateTweet([FromBody] Tweetdata tweet)
        {
            try
            {
                bool creationStatus = tweetService.CreateTweet(tweet);
                if (creationStatus)
                {
                    return Ok("Tweet created successfully");
                }
            }
            catch (Exception ex)
            {
                string status = "Meesage : " + ex.Message + " & Stacktrace: " + ex.StackTrace;
            }
            return BadRequest("Error");
        }
    }
}
